# Findkaldifeat
# -------------
#
# Finds the kaldifeat library
#
# This will define the following variables:
#
#   KALDIFEAT_FOUND  -- True if the system has the kaldifeat library
#   KALDIFEAT_INCLUDE_DIRS -- The include directories for kaldifeat
#   KALDIFEAT_LIBRARIES    -- Libraries to link against
#   KALDIFEAT_CXX_FLAGS -- Additional (required) compiler flags
#   KALDIFEAT_TORCH_VERSION_MAJOR  -- The major version of PyTorch used to compile kaldifeat
#   KALDIFEAT_TORCH_VERSION_MINOR  -- The minor version of PyTorch used to compile kaldifeat
#   KALDIFEAT_VERSION -- The version of kaldifeat
#
# and the following imported targets:
#
#   kaldifeat_core

# This file is modified from pytorch/cmake/TorchConfig.cmake.in

set(KALDIFEAT_CXX_FLAGS " -D_GLIBCXX_USE_CXX11_ABI=0")
set(KALDIFEAT_TORCH_VERSION_MAJOR 2)
set(KALDIFEAT_TORCH_VERSION_MINOR 2)
set(KALDIFEAT_VERSION 1.25.5)

if(DEFINED ENV{KALDIFEAT_INSTALL_PREFIX})
  set(KALDIFEAT_INSTALL_PREFIX $ENV{KALDIFEAT_INSTALL_PREFIX})
else()
  # Assume we are in <install-prefix>/share/cmake/kaldifeat/kaldifeatConfig.cmake
  get_filename_component(CMAKE_CURRENT_LIST_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
  get_filename_component(KALDIFEAT_INSTALL_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)
endif()

set(KALDIFEAT_INCLUDE_DIRS ${KALDIFEAT_INSTALL_PREFIX}/include)

set(KALDIFEAT_LIBRARIES kaldifeat_core)

foreach(lib IN LISTS KALDIFEAT_LIBRARIES)
  find_library(location_${lib} ${lib}
    PATHS
    "${KALDIFEAT_INSTALL_PREFIX}/lib"
    "${KALDIFEAT_INSTALL_PREFIX}/lib64"
  )

  if(NOT MSVC)
    add_library(${lib} SHARED IMPORTED)
  else()
    add_library(${lib} STATIC IMPORTED)
  endif()

  set_target_properties(${lib} PROPERTIES
    INTERFACE_INCLUDE_DIRECTORIES "${KALDIFEAT_INCLUDE_DIRS}"
      IMPORTED_LOCATION "${location_${lib}}"
      CXX_STANDARD 14
  )

  set_property(TARGET ${lib} PROPERTY INTERFACE_COMPILE_OPTIONS  -D_GLIBCXX_USE_CXX11_ABI=0)
endforeach()

include(FindPackageHandleStandardArgs)

find_package_handle_standard_args(kaldifeat DEFAULT_MSG
  location_kaldifeat_core
)
